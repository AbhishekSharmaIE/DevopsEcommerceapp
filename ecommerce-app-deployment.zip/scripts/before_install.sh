#!/bin/bash
sudo apt-get update
sudo apt-get install -y python3-pip python3-venv
sudo rm -rf /home/ubuntu/ecommerce 